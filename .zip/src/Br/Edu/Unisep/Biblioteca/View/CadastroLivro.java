package Br.Edu.Unisep.Biblioteca.View;

import Br.Edu.Unisep.Biblioteca.Model.Autor;
import Br.Edu.Unisep.Biblioteca.Model.Genero;
import Br.Edu.Unisep.Biblioteca.Model.Livro;

import javax.swing.*;
import java.util.ArrayList;

public class CadastroLivro extends JFrame {

    private static ArrayList<Livro> livros = new ArrayList<>();
    private static ArrayList<Autor> autores = new ArrayList<>();
    private static ArrayList<Genero> generos = new ArrayList<>();

    public CadastroLivro() {
        setTitle("Cadastro de Livro");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblTitulo = new JLabel("Título:");
        lblTitulo.setBounds(20, 20, 100, 25);
        add(lblTitulo);

        JTextField txtTitulo = new JTextField();
        txtTitulo.setBounds(20, 50, 200, 25);
        add(txtTitulo);

        JLabel lblAutor = new JLabel("Autor:");
        lblAutor.setBounds(20, 80, 100, 25);
        add(lblAutor);

        JComboBox<Autor> comboAutor = new JComboBox<>(autores.toArray(new Autor[0]));
        comboAutor.setBounds(20, 110, 200, 25);
        add(comboAutor);

        JLabel lblGenero = new JLabel("Gênero:");
        lblGenero.setBounds(20, 140, 100, 25);
        add(lblGenero);

        JComboBox<Genero> comboGenero = new JComboBox<>(generos.toArray(new Genero[0]));
        comboGenero.setBounds(20, 170, 200, 25);
        add(comboGenero);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(20, 210, 100, 25);
        add(btnSalvar);

        btnSalvar.addActionListener(e -> {
            String titulo = txtTitulo.getText();
            Autor autor = (Autor) comboAutor.getSelectedItem();
            Genero genero = (Genero) comboGenero.getSelectedItem();

            if (!titulo.isEmpty() && autor != null && genero != null) {
                livros.add(new Livro(titulo, autor, genero));
                JOptionPane.showMessageDialog(this, "Livro cadastrado com sucesso!");
                txtTitulo.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
            }
        });

        setVisible(true);
    }

    public static ArrayList<Livro> getLivros() {
        return livros;
    }

    public static void addAutor(Autor autor) {
        autores.add(autor);
    }

    public static void addGenero(Genero genero) {
        generos.add(genero);
    }
}
